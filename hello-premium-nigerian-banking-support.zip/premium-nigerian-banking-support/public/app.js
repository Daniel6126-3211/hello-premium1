const WA = "2349017468095";
const waUrl = msg => `https://wa.me/${WA}?text=${encodeURIComponent(msg)}`;

const services = [
 ["🏦","Bank Account Assistance","Account opening guidance, account types and access issues."],
 ["🔑","Bank Login Problems","Guidance for app, internet banking and access problems."],
 ["🔐","PIN & Security Assistance","Safe guidance for blocked or forgotten access credentials."],
 ["💳","ATM Card Services","Card request, replacement, delivery and withdrawal guidance."],
 ["▣","POS Terminal Services","POS information, setup, troubleshooting and business support."],
 ["⚡","Bill Payments","Guidance for airtime, data, electricity, cable and internet."],
 ["⚠️","Banking Complaints","Organize a failed, pending, reversed or disputed transaction."],
 ["↔","Payment Support","Help understanding payment and transaction workflows."],
 ["↯","Transaction Assistance","Support for common transfer and transaction problems."],
 ["◎","General Banking Support","Tell us what banking problem you are facing."]
];
const cards = [
 ["💳","Debit Card Information","Understand card options and official request channels."],
 ["♻️","Card Replacement","Guidance for damaged, expired or lost cards."],
 ["🏧","ATM Withdrawal Problems","Organize an ATM issue for support."],
 ["▣","Virtual Card Guidance","General information about virtual card options."]
];
const pos = [
 ["▰","POS Terminal Information","Compare terminal use cases and requirements."],
 ["◫","Small Business POS","Support for retail and small business operators."],
 ["▤","Agent Banking POS","Guidance for agent banking operations."],
 ["⚙️","POS Troubleshooting","Organize a terminal problem for assistance."],
 ["↻","POS Replacement","Guidance for damaged or unavailable terminals."]
];

function renderGrid(id, data, cls="service-card"){
  document.getElementById(id).innerHTML = data.map((x,i)=>`
    <article class="${cls}">
      <div class="${cls==="pos-card"?"pos-art":"service-icon"}">${x[0]}</div>
      <h3>${x[1]}</h3><p>${x[2]}</p>
      <a class="text-btn" data-service="${x[1]}">Request Assistance →</a>
    </article>`).join("");
}
renderGrid("serviceGrid",services);
renderGrid("cardGrid",cards,"feature-card");
renderGrid("posGrid",pos,"pos-card");

function openRequest(service){
  document.getElementById("modalTitle").textContent = service;
  document.getElementById("modalText").textContent = `You are requesting guidance for ${service}. We will prepare a safe WhatsApp support message. Do not include passwords, OTPs, PINs, CVVs or full card numbers.`;
  document.getElementById("modalWhatsApp").href = waUrl(`Hello Customer Care, I need assistance with ${service}. Please guide me through the appropriate official process. I will not send any password, OTP, PIN, CVV or full card number.`);
  document.getElementById("modal").classList.add("open");
}
document.addEventListener("click", e=>{
  const s=e.target.closest("[data-service]");
  if(s) openRequest(s.dataset.service);
  if(e.target.closest(".close") || e.target.id==="modal") document.getElementById("modal").classList.remove("open");
});

const commonMsg = "Hello Customer Care, I need assistance with banking support. Please guide me through the appropriate official process.";
["topWhatsApp","heroWhatsApp","footerWhatsApp"].forEach(id=>{
  const el=document.getElementById(id); if(el) el.href=waUrl(commonMsg);
});
document.getElementById("footerCall").href="tel:+2349017468095";

fetch("/api/visitors").then(r=>r.json()).then(d=>{
  document.getElementById("visitorCount").textContent = Number(d.count).toLocaleString();
}).catch(()=>document.getElementById("visitorCount").textContent="—");

document.getElementById("requestForm").addEventListener("submit", async e=>{
  e.preventDefault();
  const form=e.currentTarget, data=Object.fromEntries(new FormData(form));
  const result=document.getElementById("requestResult");
  try{
    const r=await fetch("/api/requests",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
    const out=await r.json();
    if(!r.ok) throw new Error(out.error||"Unable to submit");
    const msg=`Hello Customer Care, I need banking support.\n\nRequest ID: ${out.id}\nService: ${data.service}\nBank: ${data.bank||"Not specified"}\nProblem: ${data.description}\n\nPlease guide me through the appropriate official process.`;
    result.style.display="block";
    result.innerHTML=`<b>Request received: ${out.id}</b><br>Your WhatsApp message is ready. <a class="text-btn" target="_blank" rel="noopener" href="${waUrl(msg)}">Continue to WhatsApp →</a>`;
    form.reset();
  }catch(err){
    result.style.display="block"; result.style.background="#fff0f0"; result.style.color="#a52b2b"; result.textContent=err.message;
  }
});