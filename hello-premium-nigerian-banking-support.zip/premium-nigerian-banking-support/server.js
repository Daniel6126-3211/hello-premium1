const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, "data");
const COUNTER_FILE = path.join(DATA, "visitors.json");

fs.mkdirSync(DATA, { recursive: true });
if (!fs.existsSync(COUNTER_FILE)) fs.writeFileSync(COUNTER_FILE, JSON.stringify({ count: 0 }));

app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

function readCounter() {
  try { return JSON.parse(fs.readFileSync(COUNTER_FILE, "utf8")).count || 0; }
  catch { return 0; }
}
function writeCounter(count) {
  fs.writeFileSync(COUNTER_FILE, JSON.stringify({ count }, null, 2));
}

app.get("/api/visitors", (req, res) => {
  const next = readCounter() + 1;
  writeCounter(next);
  res.json({ count: next });
});

app.get("/api/health", (req, res) => res.json({ ok: true, service: "banking-support" }));

app.post("/api/requests", (req, res) => {
  const allowed = ["name","phone","bank","service","description","reference","date","amount"];
  const payload = {};
  for (const key of allowed) {
    if (typeof req.body?.[key] === "string") payload[key] = req.body[key].slice(0, 500);
  }
  if (!payload.service || !payload.description) {
    return res.status(400).json({ error: "Service and description are required." });
  }
  const id = `REQ-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;
  const record = { id, ...payload, createdAt: new Date().toISOString(), status: "Submitted" };
  const file = path.join(DATA, "requests.jsonl");
  fs.appendFileSync(file, JSON.stringify(record) + "\n");
  res.json({ ok: true, id, record });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Banking Support running on port ${PORT}`));