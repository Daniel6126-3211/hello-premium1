# Premium Nigerian Banking Support Platform

## Run locally
1. Install Node.js 18+.
2. Run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000`.

## Deployment
Deploy as a Node.js web service using:
- Build/install command: `npm install`
- Start command: `npm start`

The global visitor counter is persisted in `data/visitors.json`. For multi-instance production hosting, replace this file counter with a shared database such as PostgreSQL or Redis.

## Security
This project intentionally does not collect passwords, OTPs, ATM PINs, CVVs, full card numbers, or banking login credentials.

WhatsApp requests are prepared for the user and require the user to press Send.
